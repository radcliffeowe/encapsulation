
public class Time {
	private int hour;
	private int min;
	
	Time(int hour, int min){
		this.hour = hour;
		this.min = min;
	}

}
